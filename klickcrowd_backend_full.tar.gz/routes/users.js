import express from 'express';
import User from '../models/User.js';
import Post from '../models/Post.js';
import authMiddleware from '../middleware/auth.js';

const router = express.Router();

// @route   GET /api/users/in/:username
// @desc    Get public profile data by username
// @access  Private (You need to be logged in to view profiles)
router.get('/in/:username', authMiddleware, async (req, res) => {
    try {
        const username = req.params.username;
        
        // Find user by username
        const user = await User.findOne({ username }).select('-password');
        
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        // Fetch user's recent posts to show on their profile
        // Since Post model embeds author, we query by author.username
        const posts = await Post.find({ "author.username": user.username })
            .sort({ createdAt: -1 })
            .limit(10); // Limit to last 10 posts for performance

        res.json({
            user,
            posts
        });

    } catch (error) {
        console.error('Error fetching public profile:', error);
        res.status(500).json({ message: 'Server error fetching profile' });
    }
});

export default router;
