import express from 'express';
import Post from '../models/Post.js';

const router = express.Router();

// GET: Fetch all posts (Sorted by newest)
router.get('/', async (req, res) => {
    try {
        const posts = await Post.find().sort({ createdAt: -1 });
        res.status(200).json(posts);
    } catch (error) {
        res.status(500).json({ message: 'Error fetching posts', error: error.message });
    }
});

// POST: Create a new post
router.post('/', async (req, res) => {
    try {
        const { text, type, tags, author } = req.body;
        
        const newPost = new Post({
            text,
            type,
            tags,
            author
        });

        const savedPost = await newPost.save();
        res.status(201).json(savedPost);
    } catch (error) {
        res.status(500).json({ message: 'Error creating post', error: error.message });
    }
});

export default router;
