import express from 'express';
import Message from '../models/Message.js';
import User from '../models/User.js';
import jwt from 'jsonwebtoken';

const router = express.Router();

// Middleware to protect message routes
const auth = (req, res, next) => {
    try {
        const token = req.header('Authorization').replace('Bearer ', '');
        const decoded = jwt.verify(token, process.env.JWT_SECRET || 'secret123');
        req.user = decoded;
        next();
    } catch (e) {
        res.status(401).send({ error: 'Please authenticate.' });
    }
};

// Get conversation history with a specific user
router.get('/:userId', auth, async (req, res) => {
    try {
        const myId = req.user.id;
        const otherUserId = req.params.userId;

        const messages = await Message.find({
            $or: [
                { sender: myId, receiver: otherUserId },
                { sender: otherUserId, receiver: myId }
            ]
        }).sort({ createdAt: 1 }); // Oldest first (chronological order)

        res.json(messages);
    } catch (error) {
        res.status(500).json({ message: 'Server error fetching messages' });
    }
});

// Get list of all users that the current user has chatted with
router.get('/conversations/list', auth, async (req, res) => {
    try {
        const myId = req.user.id;

        // Find all unique users this user has messaged or received messages from
        const messages = await Message.find({
            $or: [{ sender: myId }, { receiver: myId }]
        }).sort({ createdAt: -1 });

        // Extract unique user IDs
        const contactIds = new Set();
        messages.forEach(msg => {
            if (msg.sender.toString() !== myId) contactIds.add(msg.sender.toString());
            if (msg.receiver.toString() !== myId) contactIds.add(msg.receiver.toString());
        });

        // Fetch user details for those IDs
        const contacts = await User.find({ _id: { $in: Array.from(contactIds) } })
            .select('name email role companyName verified avatar');

        res.json(contacts);
    } catch (error) {
        console.error("Error fetching conversations list", error);
        res.status(500).json({ message: 'Server error' });
    }
});

export default router;
